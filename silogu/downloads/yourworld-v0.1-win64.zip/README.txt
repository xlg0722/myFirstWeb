﻿My2DGame 测试版 0.1
====================

制作：小龙果

运行
----
1. 把整个文件夹解压到桌面或文档等可写目录。
2. 双击 My2DGame.exe。
3. 如果 Windows 提示“未知发布者”，点“更多信息” -> “仍要运行”。

不要放在 Program Files 等没有写入权限的目录，否则设置和存档无法保存。

当前内容
--------
目前是开始界面原型：主菜单、我的存档、新建世界、设置、中英文切换。
游戏内的世界/角色/挖放方块还没有实现。

操作
----
- 鼠标点击按钮
- 存档列表滚轮翻页
- F11 切换全屏
- Esc 返回上一级；主菜单退出

设置和存档
----------
第一次运行会在本文件夹生成：
  settings.txt    分辨率、动画、语言
  saves/          存档
  logs/           运行日志

删除它们可以重置。想换电脑时，把 settings.txt 和 saves/ 一起复制过去即可。

许可证
------
字体：ZCOOL KuaiLe，SIL Open Font License 1.1
      licenses/ZCOOL-KuaiLe-OFL.txt

引擎：SFML 2.6.1，zlib 许可证
      licenses/SFML.txt

如果游戏打不开，把 logs/ 里的日志发给作者。

# assets/generated

生成产物，不要手改：

- `atlas.png`：方块图集，16×16 内容 + 1px 边缘扩展，防止采样渗色
- `atlas.txt`：key → 图集像素矩形

重新生成用 `tools/build_atlas.ps1`（Phase 1 添加）。生成文件要提交，构建时不依赖 PowerShell。

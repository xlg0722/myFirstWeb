# assets/lang

内容本地化文件（未来）：

- `zh.ini`：简体中文
- `en.ini`：English

格式：`key=text`，例如 `block.stone=石头`。当前菜单文案仍在 `src/core/Localization.cpp` 的 `UiTexts` 里；内容量上来后再迁移到 key。

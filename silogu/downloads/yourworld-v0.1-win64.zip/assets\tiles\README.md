# assets/tiles

方块源贴图，统一 16×16 PNG，文件名就是方块 key，例如：

- `grass.png`
- `dirt.png`
- `stone.png`
- `wood.png`
- `leaves.png`

不要直接在这里做图集；图集由工具生成到 `assets/generated/atlas.png`。
